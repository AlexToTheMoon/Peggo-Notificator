#!/bin/bash
# Alex

while true
do
	date

heighestEventNonce=$(go run $HOME/peggo_health_check.go | jq ."heighestEventNonce")

echo  "Heighest EventNonce $heighestEventNonce"

ownEventNonce=$(go run $HOME/peggo_health_check.go | jq ."ownEventNonce")

echo "Your EventNonce is $ownEventNonce"
					sleep 2s

		if [ -z "$heighestEventNonce" ]; then
	sendmail -F Peggo -t latflat@gmail.com  < $HOME/get-error.txt 2> "/dev/null"
		elif [ $heighestEventNonce -ne $ownEventNonce ]; then
	sendmail -F Peggo -t latflat@gmail.com  < $HOME/sync-error.txt 2> "/dev/null"

		echo  ">>> Notification Email was sent! <<<"

		else 
			echo  "*** ALL GOOD ***"
			echo Next check in 3 hours.	
		fi
	sleep 3h

done
