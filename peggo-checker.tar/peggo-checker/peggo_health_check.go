package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"strconv"
	"time"
)

var url = "https://umee-api.theamsolutions.info:443"
/* HERE CAN BE YOUR LOCAL OR EXTERNAL API ENDPOINT, MORE PROVIDERS CAN BE FOUND HERE https://github.com/umee-network/umee/tree/main/networks/umee-1 */

var orchAddress = "<umee1...ORCHESTRATOR KEY>"
//HERE IS YOUR ORCHESTRATOR KEY FROM peggod.servie file -> --cosmos-from=

func main() {

	/*
		Explanation:
		
		1. Get list of validators
		2. Get orch address for each validator
		3. Get event nonce for each orch address
		4. Compare my own orch's event nonce with the others

		Each operator will decide when to trigger an alarm based on these values.
		A good baseline would be to trigger an alarm if own event nonce is not
		moving (while others do) in the last 10 minutes.
		
		Endpoints used:
		A. http://localhost:1317/cosmos/staking/v1beta1/validators?status=BOND_STATUS_BONDED
		B. http://localhost:1317/gravity/v1beta/query_delegate_keys_by_validator?validator_address=umeevaloper1frelmcs002w6w9cts38h7mxxk4aj5jje5yz7cy
		C. http://localhost:1317/gravity/v1beta/oracle/eventnonce/umee1f9xvvqre0m8hs5ya2ekgwhs9t38y7mvhep0xrl
	*/

	//printStatus()

	//for range time.Tick(5 * time.Minute)
	{
		printStatus()
	}

}

func printStatus() {
	resp, err := http.Get(url + "/cosmos/staking/v1beta1/validators?status=BOND_STATUS_BONDED")
	if err != nil {
		fmt.Println("No response from request")
	}
	defer resp.Body.Close()
	body, err := ioutil.ReadAll(resp.Body)

	var validators QueryValidatorsResponse
	if err := json.Unmarshal(body, &validators); err != nil {
		fmt.Println("Can not unmarshal JSON")
	}

	orchAddresses := []string{}

	for _, v := range validators.Validators {
		resp, err := http.Get(url + "/gravity/v1beta/query_delegate_keys_by_validator?validator_address=" + v.OperatorAddress)
		if err != nil {
			fmt.Println("No response from request")
		}
		defer resp.Body.Close()
		body, err := ioutil.ReadAll(resp.Body)

		var result QueryDelegateKeysResponse
		if err := json.Unmarshal(body, &result); err != nil {
			fmt.Println("Can not unmarshal JSON")
		}

		orchAddresses = append(orchAddresses, result.OrchestratorAddress)
	}

	eventNonces := []uint64{}
	ownEventNonce := uint64(0)
	heighestEventNonce := uint64(0)
	higherThanOwn := uint64(0)

	for _, v := range orchAddresses {
		resp, err := http.Get(url + "/gravity/v1beta/oracle/eventnonce/" + v)
		if err != nil {
			fmt.Println("No response from request")
		}
		defer resp.Body.Close()
		body, err := ioutil.ReadAll(resp.Body)

		var result QueryLastEventNonceResponse
		if err := json.Unmarshal(body, &result); err != nil {
			fmt.Println("Can not unmarshal JSON")
		}

		evtNonce, _ := strconv.ParseUint(result.EventNonce, 10, 64)

		if orchAddress == v {
			ownEventNonce = evtNonce
		}

		if evtNonce > heighestEventNonce {
			heighestEventNonce = evtNonce
		}

		if evtNonce > ownEventNonce {
			higherThanOwn++
		}

		eventNonces = append(eventNonces, evtNonce)
	}

	data := map[string]interface{}{}
	data["ownEventNonce"] = ownEventNonce
	data["heighestEventNonce"] = heighestEventNonce
	data["eventNonces"] = eventNonces
	data["percentageHigherThanOwn"] = float64(higherThanOwn) / float64(len(orchAddresses))
	data["timestamp"] = time.Now().Unix()
	out, _ := json.Marshal(data)
	fmt.Println(string(out))

	// Example output
	// {"eventNonces":[11816,11817,11817],"heighestEventNonce":11817,"ownEventNonce":11816,"percentageHigherThanOwn":0.6666666666666666,"timestamp":1644850500}
}

type QueryValidatorsResponse struct {
	Validators []struct {
		OperatorAddress string `json:"operator_address"`
	} `json:"validators"`
	Pagination struct {
		NextKey interface{} `json:"next_key"`
		Total   string      `json:"total"`
	} `json:"pagination"`
}

type QueryDelegateKeysResponse struct {
	EthAddress          string `json:"eth_address"`
	OrchestratorAddress string `json:"orchestrator_address"`
}

type QueryLastEventNonceResponse struct {
	EventNonce string `json:"event_nonce"`
}
